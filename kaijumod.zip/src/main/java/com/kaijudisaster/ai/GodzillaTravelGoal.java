package com.kaijudisaster.ai;

import com.kaijudisaster.entity.GodzillaEntity;
import java.util.EnumSet;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Wandert zielstrebig auf Land zu (nächster Spieler als Stellvertreter für die Stadt),
 * ohne Navigation – für eine 18x50-Hitbox taugt Vanilla-Pathfinding nicht.
 * Wählt regelmäßig neu, damit Godzilla nicht auf ein einzelnes Ziel fixiert bleibt.
 */
public class GodzillaTravelGoal extends Goal {
    private final GodzillaEntity godzilla;
    private Vec3 target;
    private int retargetIn;

    public GodzillaTravelGoal(GodzillaEntity godzilla) {
        this.godzilla = godzilla;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        return godzilla.getPhase() == GodzillaEntity.Phase.WALK;
    }

    @Override
    public boolean canContinueToUse() {
        return canUse();
    }

    @Override
    public void tick() {
        if (--retargetIn <= 0 || target == null || godzilla.position().distanceToSqr(target) < 30 * 30) {
            retargetIn = 200 + godzilla.getRandom().nextInt(200);
            target = pickTarget();
        }
        if (target == null) return;
        godzilla.getLookControl().setLookAt(target.x, godzilla.getEyeY(), target.z, 4.0F, 4.0F);
        godzilla.getMoveControl().setWantedPosition(target.x, target.y, target.z, 1.0);
    }

    private Vec3 pickTarget() {
        Player p = godzilla.level().getNearestPlayer(godzilla, 600.0);
        if (p != null) {
            // leichter seitlicher Versatz, damit nicht jeder Weg schnurgerade auf eine Person zielt
            double off = (godzilla.getRandom().nextDouble() - 0.5) * 80.0;
            return p.position().add(off, 0, off);
        }
        // kein Spieler in der Nähe: grob landeinwärts weiterlaufen
        return godzilla.position().add(godzilla.getLookAngle().scale(120).multiply(1, 0, 1));
    }
}
