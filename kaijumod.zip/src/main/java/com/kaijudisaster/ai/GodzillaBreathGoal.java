package com.kaijudisaster.ai;

import com.kaijudisaster.effects.AtomicBreathEffect;
import com.kaijudisaster.entity.GodzillaEntity;
import com.kaijudisaster.registry.ModSounds;
import java.util.EnumSet;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;

/** Lädt auf, wenn ein Spieler im Einflussbereich ist, und feuert dann den Atomic Breath. */
public class GodzillaBreathGoal extends Goal {
    private static final double RANGE = 140.0;
    private final GodzillaEntity godzilla;
    private int cooldown = 200;
    private Player victim;

    public GodzillaBreathGoal(GodzillaEntity godzilla) {
        this.godzilla = godzilla;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        if (cooldown > 0) {
            cooldown--;
            return false;
        }
        if (godzilla.getPhase() != GodzillaEntity.Phase.WALK) return false;
        victim = godzilla.level().getNearestPlayer(godzilla, RANGE);
        return victim != null && !victim.isCreative() && !victim.isSpectator();
    }

    @Override
    public boolean canContinueToUse() {
        return godzilla.getPhase() == GodzillaEntity.Phase.CHARGE
                || godzilla.getPhase() == GodzillaEntity.Phase.FIRE;
    }

    @Override
    public void start() {
        godzilla.setPhase(GodzillaEntity.Phase.CHARGE);
        godzilla.playSound(ModSounds.BREATH_CHARGE.get(), 10.0F, 1.0F);
    }

    @Override
    public void tick() {
        if (victim != null && victim.isAlive()) {
            godzilla.getLookControl().setLookAt(victim.getX(), victim.getEyeY(), victim.getZ(), 6.0F, 6.0F);
        }
        godzilla.getNavigation().stop();
        int t = godzilla.getPhaseTicks();
        switch (godzilla.getPhase()) {
            case CHARGE -> {
                AtomicBreathEffect.chargeParticles(godzilla);
                if (t >= GodzillaEntity.CHARGE_TICKS) {
                    godzilla.setPhase(GodzillaEntity.Phase.FIRE);
                    godzilla.playSound(ModSounds.BREATH_FIRE.get(), 12.0F, 1.0F);
                }
            }
            case FIRE -> {
                AtomicBreathEffect.fireTick(godzilla, t);
                if (t >= GodzillaEntity.FIRE_TICKS) {
                    godzilla.setPhase(GodzillaEntity.Phase.WALK);
                }
            }
            default -> {}
        }
    }

    @Override
    public void stop() {
        cooldown = 300 + godzilla.getRandom().nextInt(300);
        victim = null;
    }
}
