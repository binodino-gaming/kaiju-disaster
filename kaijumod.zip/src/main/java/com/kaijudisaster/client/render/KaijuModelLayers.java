package com.kaijudisaster.client.render;

import com.kaijudisaster.KaijuMod;
import com.kaijudisaster.client.model.GodzillaModel;
import com.kaijudisaster.registry.ModEntities;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

public class KaijuModelLayers {
    public static final ModelLayerLocation GODZILLA =
            new ModelLayerLocation(KaijuMod.id("godzilla"), "main");

    @EventBusSubscriber(modid = KaijuMod.MOD_ID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class ClientSetup {
        @SubscribeEvent
        public static void layers(EntityRenderersEvent.RegisterLayerDefinitions event) {
            event.registerLayerDefinition(GODZILLA, GodzillaModel::createLayer);
        }

        @SubscribeEvent
        public static void renderers(EntityRenderersEvent.RegisterRenderers event) {
            event.registerEntityRenderer(ModEntities.GODZILLA.get(), GodzillaRenderer::new);
        }
    }
}
