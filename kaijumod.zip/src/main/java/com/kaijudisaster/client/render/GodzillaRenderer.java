package com.kaijudisaster.client.render;

import com.kaijudisaster.KaijuMod;
import com.kaijudisaster.client.model.GodzillaModel;
import com.kaijudisaster.entity.GodzillaEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

public class GodzillaRenderer extends MobRenderer<GodzillaEntity, GodzillaModel> {
    private static final ResourceLocation TEXTURE = KaijuMod.id("textures/entity/godzilla.png");
    private static final ResourceLocation GLOW_EYES = KaijuMod.id("textures/entity/godzilla_glow_eyes.png");
    private static final ResourceLocation GLOW_SPINES = KaijuMod.id("textures/entity/godzilla_glow_spines.png");
    public static final float SCALE = 4.0F;

    public GodzillaRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new GodzillaModel(ctx.bakeLayer(KaijuModelLayers.GODZILLA)), 0.0F);
        addLayer(new GlowLayer(this));
    }

    @Override
    public ResourceLocation getTextureLocation(GodzillaEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(GodzillaEntity entity, PoseStack pose, float partialTick) {
        pose.scale(SCALE, SCALE, SCALE);
    }

    @Override
    public boolean shouldRender(GodzillaEntity e, net.minecraft.client.renderer.culling.Frustum f,
                                double x, double y, double z) {
        return true; // riesig: nie wegen der Bounding Box weggeculled
    }

    private static class GlowLayer extends RenderLayer<GodzillaEntity, GodzillaModel> {
        GlowLayer(GodzillaRenderer parent) {
            super(parent);
        }

        @Override
        public void render(PoseStack pose, MultiBufferSource buffers, int light, GodzillaEntity g,
                           float limbSwing, float limbSwingAmount, float partial,
                           float age, float headYaw, float headPitch) {
            // Augen: immer an (0xFFFFFFFF = volles Weiß in ARGB)
            this.getParentModel().renderToBuffer(pose, buffers.getBuffer(RenderType.eyes(GLOW_EYES)),
                    0xF000F0, OverlayTexture.NO_OVERLAY, 0xFFFFFFFF);
            
            // Dornen: Helligkeit folgt dem Aufladen, beim Feuern leichtes Flackern
            float c = g.getChargeProgress();
            if (c <= 0.01F) return;
            float flicker = g.getPhase() == GodzillaEntity.Phase.FIRE
                    ? 0.85F + 0.15F * (float) Math.sin(age * 1.7F) : 1F;
            
            // Berechnung der Farb-Helligkeit (von 0 bis 255 für die Farbkanäle)
            int alpha = 255;
            int colorValue = Math.clamp((int)(c * c * flicker * 255), 0, 255);
            int packedColor = (alpha << 24) | (colorValue << 16) | (colorValue << 8) | colorValue;

            this.getParentModel().renderToBuffer(pose, buffers.getBuffer(RenderType.eyes(GLOW_SPINES)),
                    0xF000F0, OverlayTexture.NO_OVERLAY, packedColor);
        }
    }
}
