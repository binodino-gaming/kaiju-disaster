package com.kaijudisaster.client.model;

import com.kaijudisaster.entity.GodzillaEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

/**
 * Godzilla im 4x-Maßstab: Modell ist ~200 px hoch, der Renderer skaliert mit 4 => 50 Blöcke.
 * UV-Regionen (Textur 512x512): Dornen bei (0,470), Augen bei (40,470) – diese Bereiche werden
 * in den Glow-Texturen hell gezeichnet.
 */
public class GodzillaModel extends EntityModel<GodzillaEntity> {
    public static final int TEX = 512;

    private final ModelPart root;
    private final ModelPart body, head, jaw, armL, armR, legL, legR, tail1, tail2, tail3;

    public GodzillaModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.legL = root.getChild("leg_l");
        this.legR = root.getChild("leg_r");
        this.head = body.getChild("neck").getChild("head");
        this.jaw = head.getChild("jaw");
        this.armL = body.getChild("arm_l");
        this.armR = body.getChild("arm_r");
        this.tail1 = body.getChild("tail1");
        this.tail2 = tail1.getChild("tail2");
        this.tail3 = tail2.getChild("tail3");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        // Beine (Pivot an der Hüfte, Fuß am Boden y=24 in Modellraum)
        for (int side : new int[]{-1, 1}) {
            String n = side < 0 ? "leg_r" : "leg_l";
            PartDefinition leg = root.addOrReplaceChild(n,
                    CubeListBuilder.create().texOffs(0, 0).addBox(-10, 0, -10, 20, 78, 22),
                    PartPose.offset(side * 15, 24 - 82, 0));
            leg.addOrReplaceChild(n + "_foot",
                    CubeListBuilder.create().texOffs(0, 110).addBox(-11, 0, -20, 22, 8, 32),
                    PartPose.offset(0, 74, 0));
        }

        // Torso, leicht nach vorn geneigt
        PartDefinition body = root.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(100, 0).addBox(-22, -72, -15, 44, 74, 32),
                PartPose.offsetAndRotation(0, 24 - 82, 2, 0.28F, 0, 0));

        PartDefinition neck = body.addOrReplaceChild("neck",
                CubeListBuilder.create().texOffs(100, 120).addBox(-12, -26, -10, 24, 28, 22),
                PartPose.offsetAndRotation(0, -66, -2, -0.25F, 0, 0));
        PartDefinition head = neck.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(250, 0).addBox(-13, -17, -30, 26, 22, 36)
                        // Augen (eigene UV-Region für Glow)
                        .texOffs(40, 470).addBox(-12, -12, -31, 6, 4, 2)
                        .texOffs(40, 470).addBox(6, -12, -31, 6, 4, 2),
                PartPose.offset(0, -22, -4));
        head.addOrReplaceChild("jaw",
                CubeListBuilder.create().texOffs(250, 70).addBox(-11, 0, -28, 22, 7, 30),
                PartPose.offset(0, 2, 0));

        // Arme
        for (int side : new int[]{-1, 1}) {
            String n = side < 0 ? "arm_r" : "arm_l";
            body.addOrReplaceChild(n,
                    CubeListBuilder.create().texOffs(250, 140).addBox(-5, 0, -5, 10, 48, 10)
                            .texOffs(250, 200).addBox(-6, 46, -7, 12, 10, 14),
                    PartPose.offsetAndRotation(side * 25, -56, -6, -0.55F, 0, 0));
        }

        // Schwanz (3 Segmente)
        PartDefinition tail1 = body.addOrReplaceChild("tail1",
                CubeListBuilder.create().texOffs(0, 200).addBox(-15, -14, 0, 30, 28, 44),
                PartPose.offsetAndRotation(0, -4, 14, -0.45F, 0, 0));
        PartDefinition tail2 = tail1.addOrReplaceChild("tail2",
                CubeListBuilder.create().texOffs(0, 300).addBox(-11, -10, 0, 22, 20, 44),
                PartPose.offset(0, 0, 42));
        tail2.addOrReplaceChild("tail3",
                CubeListBuilder.create().texOffs(0, 380).addBox(-6, -6, 0, 12, 12, 46),
                PartPose.offset(0, 0, 42));

        // Rückendornen: 3 Reihen auf Rücken, Hals-Ansatz und Schwanz (gleiche UV => gleiche Glow-Region)
        CubeListBuilder spine = CubeListBuilder.create().texOffs(0, 470).addBox(-1, -16, -8, 2, 16, 16);
        for (int i = 0; i < 5; i++) {
            float y = -62 + i * 14;
            body.addOrReplaceChild("spine_m" + i, spine,
                    PartPose.offsetAndRotation(0, y, 17, 0.5F, 0, 0));
            body.addOrReplaceChild("spine_l" + i, spine,
                    PartPose.offsetAndRotation(-9, y + 4, 16, 0.5F, 0, -0.35F));
            body.addOrReplaceChild("spine_r" + i, spine,
                    PartPose.offsetAndRotation(9, y + 4, 16, 0.5F, 0, 0.35F));
        }
        for (int i = 0; i < 3; i++) {
            tail1.addOrReplaceChild("spine_t" + i, spine, PartPose.offset(0, -14, 8 + i * 12));
        }
        return LayerDefinition.create(mesh, TEX, TEX);
    }

    @Override
    public void setupAnim(GodzillaEntity g, float limbSwing, float limbSwingAmount,
                          float age, float headYaw, float headPitch) {
        float swing = Mth.cos(limbSwing * 0.35F) * 0.55F * limbSwingAmount;
        legL.xRot = swing;
        legR.xRot = -swing;
        armL.xRot = -0.55F - swing * 0.5F;
        armR.xRot = -0.55F + swing * 0.5F;
        body.zRot = Mth.sin(limbSwing * 0.35F) * 0.04F * limbSwingAmount;

        head.yRot = Mth.clamp(headYaw, -50, 50) * Mth.DEG_TO_RAD * 0.6F;
        head.xRot = headPitch * Mth.DEG_TO_RAD * 0.5F;

        float charge = g.getChargeProgress();
        jaw.xRot = charge * 0.65F + Mth.sin(age * 0.03F) * 0.02F;
        head.xRot -= charge * 0.25F; // Kopf hebt sich beim Aufladen

        float sway = Mth.sin(age * 0.05F + limbSwing * 0.2F) * (0.08F + 0.1F * limbSwingAmount);
        tail1.yRot = sway;
        tail2.yRot = sway * 1.2F;
        tail3.yRot = sway * 1.4F;
    }

    @Override
    public void renderToBuffer(PoseStack pose, VertexConsumer buffer, int light, int overlay, int color) {
        root.render(pose, buffer, light, overlay, color);
    }
}
