package com.kaijudisaster.client;

import com.kaijudisaster.KaijuMod;
import com.kaijudisaster.entity.GodzillaEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ViewportEvent;

/** Kamerawackeln abhängig von Entfernung zu Godzilla und seiner Aktion. */
@EventBusSubscriber(modid = KaijuMod.MOD_ID, value = Dist.CLIENT)
public class CameraEffects {
    private static final double MAX_DIST = 220.0;

    @SubscribeEvent
    public static void onCamera(ViewportEvent.ComputeCameraAngles event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        float intensity = 0;
        for (GodzillaEntity g : mc.level.getEntitiesOfClass(GodzillaEntity.class,
                mc.player.getBoundingBox().inflate(MAX_DIST))) {
            double d = Math.sqrt(g.distanceToSqr(mc.player));
            float falloff = (float) Mth.clamp(1.0 - d / MAX_DIST, 0, 1);
            float base = switch (g.getPhase()) {
                case EMERGE -> 0.5F;
                case WALK -> g.getDeltaMovement().horizontalDistanceSqr() > 1.0E-4 ? 0.35F : 0.1F;
                case CHARGE -> 0.4F + 0.8F * g.getChargeProgress();
                case FIRE -> 1.2F;
            };
            intensity = Math.max(intensity, base * falloff * falloff);
        }
        if (intensity <= 0.01F) return;

        float t = (mc.player.tickCount + (float) event.getPartialTick());
        event.setPitch(event.getPitch() + Mth.sin(t * 1.9F) * 0.9F * intensity);
        event.setYaw(event.getYaw() + Mth.cos(t * 2.3F) * 0.7F * intensity);
        event.setRoll(event.getRoll() + Mth.sin(t * 1.3F) * 0.5F * intensity);
    }
}
