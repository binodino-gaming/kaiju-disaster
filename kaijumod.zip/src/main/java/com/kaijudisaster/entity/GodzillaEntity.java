package com.kaijudisaster.entity;

import com.kaijudisaster.ai.GodzillaBreathGoal;
import com.kaijudisaster.ai.GodzillaTravelGoal;
import com.kaijudisaster.destruction.DestructionLevel;
import com.kaijudisaster.destruction.DestructionManager;
import com.kaijudisaster.event.KaijuManager;
import com.kaijudisaster.registry.ModSounds;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.tags.FluidTags;

public class GodzillaEntity extends Monster {
    public static final int EMERGE_TICKS = 160;
    public static final int CHARGE_TICKS = 100;
    public static final int FIRE_TICKS = 80;

    public enum Phase { EMERGE, WALK, CHARGE, FIRE }

    private static final EntityDataAccessor<Integer> DATA_PHASE =
            SynchedEntityData.defineId(GodzillaEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_PHASE_TICKS =
            SynchedEntityData.defineId(GodzillaEntity.class, EntityDataSerializers.INT);

    private final ServerBossEvent bossEvent = new ServerBossEvent(
            Component.literal("GODZILLA"), BossEvent.BossBarColor.WHITE, BossEvent.BossBarOverlay.NOTCHED_20);

    private boolean claimed;

    public GodzillaEntity(EntityType<? extends GodzillaEntity> type, Level level) {
        super(type, level);
        this.xpReward = 0;
        this.noCulling = true;
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 2000.0)
                .add(Attributes.MOVEMENT_SPEED, 0.45)
                .add(Attributes.ATTACK_DAMAGE, 60.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
                .add(Attributes.FOLLOW_RANGE, 256.0)
                .add(Attributes.STEP_HEIGHT, 8.0)
                .add(Attributes.SCALE, 1.0);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_PHASE, Phase.EMERGE.ordinal());
        builder.define(DATA_PHASE_TICKS, 0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new GodzillaBreathGoal(this));
        this.goalSelector.addGoal(2, new GodzillaTravelGoal(this));
    }

    // ---- Phase ----

    public Phase getPhase() {
        return Phase.values()[Math.floorMod(this.entityData.get(DATA_PHASE), Phase.values().length)];
    }

    public void setPhase(Phase phase) {
        this.entityData.set(DATA_PHASE, phase.ordinal());
        this.entityData.set(DATA_PHASE_TICKS, 0);
    }

    public int getPhaseTicks() {
        return this.entityData.get(DATA_PHASE_TICKS);
    }

    /** 0..1, für Client-Rendering (Dornen glühen) */
    public float getChargeProgress() {
        return switch (getPhase()) {
            case CHARGE -> Math.min(1f, getPhaseTicks() / (float) CHARGE_TICKS);
            case FIRE -> 1f;
            default -> 0f;
        };
    }

    // ---- Spawn-Lock ----

    @Override
    public boolean checkSpawnRules(net.minecraft.world.level.LevelAccessor level, MobSpawnType type) {
        return true;
    }

    private boolean claimLock() {
        if (claimed || !(level() instanceof ServerLevel sl)) return true;
        claimed = KaijuManager.get(sl.getServer()).tryClaimGodzilla(this.uuid, sl.getGameTime());
        return claimed;
    }

    /** Wird vom Join-Event aufgerufen. false => Entity darf nicht in die Welt. */
    public boolean acquireGlobalLock() {
        return claimLock();
    }

    @Override
    public void remove(RemovalReason reason) {
        if (reason.shouldDestroy() && level() instanceof ServerLevel sl && claimed) {
            KaijuManager.get(sl.getServer()).releaseGodzilla(this.uuid, sl.getGameTime(), 20L * 60 * 30);
        }
        bossEvent.removeAllPlayers();
        super.remove(reason);
    }

    // ---- Tick ----

    @Override
    public void tick() {
        super.tick();
        this.entityData.set(DATA_PHASE_TICKS, getPhaseTicks() + 1);
        if (level() instanceof ServerLevel sl) {
            KaijuManager.get(sl.getServer()).heartbeat(this.uuid, sl.getGameTime());
            bossEvent.setProgress(getHealth() / getMaxHealth());
            tickEmerge();
            tickStomp(sl);
        }
    }

    private void tickEmerge() {
        if (getPhase() != Phase.EMERGE) return;
        // Beim Auftauchen langsam nach oben, bis der Körper aus dem Wasser ragt
        int t = getPhaseTicks();
        setNoGravity(true);
        setDeltaMovement(0, 0.3, 0);
        if (t == EMERGE_TICKS - 40) playSound(ModSounds.GODZILLA_ROAR.get(), 12.0F, 0.6F);
        if (t >= EMERGE_TICKS) {
            setNoGravity(false);
            setPhase(Phase.WALK);
        }
    }

    private void tickStomp(ServerLevel sl) {
        if (getPhase() != Phase.WALK) return;
        if (tickCount % 12 != 0 || getDeltaMovement().horizontalDistanceSqr() < 1.0E-4) return;
        playSound(ModSounds.GODZILLA_STEP.get(), 6.0F, 0.7F);
        DestructionManager.stomp(sl, this.blockPosition(), DestructionLevel.MEDIUM);
    }

    public boolean isInDeepWater() {
        FluidState fluid = level().getFluidState(this.blockPosition().above(4));
        return fluid.is(FluidTags.WATER);
    }

    // ---- Boss-Bar ----

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossEvent.removePlayer(player);
    }

    // ---- Verhalten ----

    @Override
    public boolean canBeLeashed() { return false; }

    @Override
    public boolean isPushable() { return false; }

    @Override
    public boolean removeWhenFarAway(double distance) { return false; }

    @Override
    public boolean canDrownInFluidType(net.neoforged.neoforge.fluids.FluidType type) { return false; }

    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        // Während des Auftauchens unverwundbar, sonst normales Verhalten (hoher HP-Pool)
        return getPhase() == Phase.EMERGE || super.isInvulnerableTo(source);
    }

    @Override
    protected SoundEvent getAmbientSound() { return ModSounds.GODZILLA_ROAR.get(); }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Phase", getPhase().ordinal());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.entityData.set(DATA_PHASE, tag.getInt("Phase"));
    }
}
