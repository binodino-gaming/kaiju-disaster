package com.kaijudisaster.destruction;

public enum DestructionLevel {
    LIGHT(2, 40),
    MEDIUM(4, 160),
    HEAVY(7, 600),
    NUCLEAR(40, 6000);

    public final int radius;
    /** Max. Blöcke, die pro Aufruf/Tick verarbeitet werden (Server-Budget). */
    public final int blockBudget;

    DestructionLevel(int radius, int blockBudget) {
        this.radius = radius;
        this.blockBudget = blockBudget;
    }
}
