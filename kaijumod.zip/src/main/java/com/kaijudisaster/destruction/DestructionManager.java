package com.kaijudisaster.destruction;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Budgetierte Zerstörung: pro Aufruf wird nur eine begrenzte Zahl Blöcke verändert,
 * Updates werden ohne Nachbar-Benachrichtigung gesetzt (Flag 2 | 16) um Lag zu vermeiden.
 */
public final class DestructionManager {
    private static final int FLAGS = 2 | 16;

    private DestructionManager() {}

    /** Fußstapfen: zerstört einen flachen Bereich unter und knapp über dem Fuß. */
    public static void stomp(ServerLevel level, BlockPos center, DestructionLevel dl) {
        sphere(level, center, dl.radius, 2, dl.blockBudget, 0.35f);
    }

    /** Zerstört eine Kugel/flache Scheibe; yRadius begrenzt die vertikale Ausdehnung. */
    public static int sphere(ServerLevel level, BlockPos center, int radius, int yRadius,
                             int budget, float fireChance) {
        int destroyed = 0;
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        int r2 = radius * radius;
        for (int dx = -radius; dx <= radius && destroyed < budget; dx++) {
            for (int dz = -radius; dz <= radius && destroyed < budget; dz++) {
                if (dx * dx + dz * dz > r2) continue;
                for (int dy = -1; dy <= yRadius && destroyed < budget; dy++) {
                    pos.set(center.getX() + dx, center.getY() + dy, center.getZ() + dz);
                    if (destroy(level, pos, fireChance)) destroyed++;
                }
            }
        }
        return destroyed;
    }

    private static boolean destroy(ServerLevel level, BlockPos pos, float fireChance) {
        BlockState state = level.getBlockState(pos);
        if (state.isAir() || state.getDestroySpeed(level, pos) < 0) return false; // Bedrock etc.
        if (!level.getFluidState(pos).isEmpty()) return false;                     // Wasser nicht anfassen
        boolean burnable = state.is(BlockTags.LEAVES) || state.is(BlockTags.LOGS)
                || state.is(BlockTags.PLANKS) || state.is(BlockTags.WOODEN_STAIRS);
        level.setBlock(pos, Blocks.AIR.defaultBlockState(), FLAGS);
        if (burnable && level.random.nextFloat() < fireChance
                && level.getBlockState(pos.below()).isSolid()) {
            level.setBlock(pos, Blocks.FIRE.defaultBlockState(), FLAGS);
        }
        return true;
    }
}
