package com.kaijudisaster;

import com.kaijudisaster.registry.ModCreativeTabs;
import com.kaijudisaster.registry.ModEntities;
import com.kaijudisaster.registry.ModItems;
import com.kaijudisaster.registry.ModSounds;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;

@Mod(KaijuMod.MOD_ID)
public class KaijuMod {
    public static final String MOD_ID = "kaiju_disaster";

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MOD_ID, path);
    }

    public KaijuMod(IEventBus modBus) {
        ModItems.ITEMS.register(modBus);
        ModEntities.ENTITIES.register(modBus);
        ModSounds.SOUNDS.register(modBus);
        ModCreativeTabs.TABS.register(modBus);
    }
}
