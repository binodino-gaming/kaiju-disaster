package com.kaijudisaster.registry;

import com.kaijudisaster.KaijuMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, KaijuMod.MOD_ID);

    public static final DeferredHolder<SoundEvent, SoundEvent> GODZILLA_ROAR = reg("godzilla_roar");
    public static final DeferredHolder<SoundEvent, SoundEvent> GODZILLA_STEP = reg("godzilla_step");
    public static final DeferredHolder<SoundEvent, SoundEvent> BREATH_CHARGE = reg("breath_charge");
    public static final DeferredHolder<SoundEvent, SoundEvent> BREATH_FIRE = reg("breath_fire");
    public static final DeferredHolder<SoundEvent, SoundEvent> SIREN = reg("siren");

    private static DeferredHolder<SoundEvent, SoundEvent> reg(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(KaijuMod.id(name)));
    }
}
