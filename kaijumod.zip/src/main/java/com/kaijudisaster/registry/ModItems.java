package com.kaijudisaster.registry;

import com.kaijudisaster.KaijuMod;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Jedes Item wird über {@link #add} registriert und landet automatisch im Creative-Tab,
 * in der Reihenfolge der Registrierung. Neue Items brauchen keine weitere Anpassung.
 */
public class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(KaijuMod.MOD_ID);

    /** Reihenfolge = Sortierung im Creative-Tab. */
    public static final List<DeferredItem<? extends Item>> TAB_ORDER = new ArrayList<>();

    public static final DeferredItem<DeferredSpawnEggItem> GODZILLA_SPAWN_EGG = add(
            "godzilla_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.GODZILLA, 0x0B0B0F, 0x3AA7FF, new Item.Properties()));

    private static <T extends Item> DeferredItem<T> add(String name, Supplier<T> factory) {
        DeferredItem<T> item = ITEMS.register(name, factory);
        TAB_ORDER.add(item);
        return item;
    }
}
