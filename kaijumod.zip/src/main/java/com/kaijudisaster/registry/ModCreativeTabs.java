package com.kaijudisaster.registry;

import com.kaijudisaster.KaijuMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, KaijuMod.MOD_ID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.kaiju_disaster.main"))
                    .icon(() -> ModItems.GODZILLA_SPAWN_EGG.get().getDefaultInstance())
                    .displayItems((params, output) ->
                            ModItems.TAB_ORDER.forEach(item -> output.accept(item.get())))
                    .build());
}
