package com.kaijudisaster.registry;

import com.kaijudisaster.KaijuMod;
import com.kaijudisaster.entity.GodzillaEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, KaijuMod.MOD_ID);

    // Hitbox 18 x 50 Blöcke; trackingRange 256 damit er aus der Ferne sichtbar bleibt
    public static final DeferredHolder<EntityType<?>, EntityType<GodzillaEntity>> GODZILLA =
            ENTITIES.register("godzilla", () -> EntityType.Builder
                    .of(GodzillaEntity::new, MobCategory.MONSTER)
                    .sized(18.0F, 50.0F)
                    .fireImmune()
                    .clientTrackingRange(256)
                    .updateInterval(1)
                    .build(KaijuMod.id("godzilla").toString()));
}
