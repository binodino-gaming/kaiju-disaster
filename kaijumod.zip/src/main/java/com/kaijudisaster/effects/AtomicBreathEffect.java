package com.kaijudisaster.effects;

import com.kaijudisaster.destruction.DestructionManager;
import com.kaijudisaster.entity.GodzillaEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Serverseitige Logik + Partikel des Atomic Breath. Alles budgetiert, keine Entity-Massen. */
public final class AtomicBreathEffect {
    private static final double RANGE = 110.0;
    private static final double STEP = 2.5;

    private AtomicBreathEffect() {}

    private static Vec3 mouth(GodzillaEntity g) {
        // Kopf etwa auf 85 % der Körperhöhe, leicht nach vorn versetzt
        Vec3 look = g.getLookAngle();
        return g.position().add(0, g.getBbHeight() * 0.85, 0).add(look.scale(7.0));
    }

    public static void chargeParticles(GodzillaEntity g) {
        if (!(g.level() instanceof ServerLevel level)) return;
        float p = g.getChargeProgress();
        Vec3 m = mouth(g);
        int count = 2 + (int) (p * 12);
        // Energie läuft vom Rücken zum Maul
        for (int i = 0; i < count; i++) {
            double h = g.getBbHeight() * (0.35 + 0.5 * level.random.nextDouble());
            Vec3 start = g.position().add((level.random.nextDouble() - 0.5) * 6, h, (level.random.nextDouble() - 0.5) * 6);
            Vec3 v = m.subtract(start).normalize().scale(0.6);
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, start.x, start.y, start.z, 0, v.x, v.y, v.z, 1.0);
        }
        level.sendParticles(ParticleTypes.END_ROD, m.x, m.y, m.z, 2 + (int) (p * 6), 1.5, 1.5, 1.5, 0.02);
    }

    public static void fireTick(GodzillaEntity g, int tick) {
        if (!(g.level() instanceof ServerLevel level)) return;
        Vec3 dir = g.getLookAngle();
        Vec3 pos = mouth(g);
        int budget = 220; // Blöcke pro Tick für den ganzen Strahl
        for (double d = 0; d < RANGE && budget > 0; d += STEP) {
            Vec3 p = pos.add(dir.scale(d));
            level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, p.x, p.y, p.z, 4, 0.8, 0.8, 0.8, 0.01);
            level.sendParticles(ParticleTypes.END_ROD, p.x, p.y, p.z, 2, 0.4, 0.4, 0.4, 0.05);
            if (d % 10 < STEP) {
                level.sendParticles(ParticleTypes.LARGE_SMOKE, p.x, p.y, p.z, 2, 1.2, 1.2, 1.2, 0.02);
            }
            BlockPos bp = BlockPos.containing(p);
            // Strahl endet am ersten festen Block, sprengt dort aber einen Krater
            if (level.getBlockState(bp).isSolidRender(level, bp) || level.getBlockState(bp).canOcclude()) {
                if (tick % 4 == 0) {
                    budget -= DestructionManager.sphere(level, bp, 5, 5, budget, 0.4f);
                    level.sendParticles(ParticleTypes.EXPLOSION, p.x, p.y, p.z, 1, 2, 2, 2, 0);
                }
                break;
            }
            damageAround(g, level, p);
        }
    }

    private static void damageAround(GodzillaEntity g, ServerLevel level, Vec3 p) {
        AABB box = new AABB(p, p).inflate(3.5);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, e -> e != g)) {
            e.hurt(level.damageSources().mobAttack(g), 20.0F);
            Vec3 push = e.position().subtract(p).normalize().scale(1.5).add(0, 0.6, 0);
            e.setDeltaMovement(e.getDeltaMovement().add(push));
            e.hurtMarked = true;
            e.setRemainingFireTicks(100);
        }
    }
}
