package com.kaijudisaster.event;

import com.kaijudisaster.KaijuMod;
import java.util.UUID;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * Zentraler Manager (pro Server, gespeichert im Overworld-DataStorage).
 * Hält den globalen Spawn-Lock ({@code GodzillaAlive}), den Event-Zustand und Cooldowns.
 * Künftige Kaiju können hier mit eigenen Slots ergänzt werden.
 */
public class KaijuManager extends SavedData {
    private static final String NAME = KaijuMod.MOD_ID + "_manager";
    /** Ohne Lebenszeichen so lange (Ticks), wird der Lock als verwaist freigegeben. */
    private static final long STALE_TICKS = 20L * 60 * 20;

    private boolean godzillaAlive;
    private UUID godzillaId;
    private long lastSeenTick;
    private long cooldownUntil;
    private KaijuEventState state = KaijuEventState.NORMAL;

    public static KaijuManager get(MinecraftServer server) {
        ServerLevel overworld = server.overworld();
        return overworld.getDataStorage().computeIfAbsent(
                new SavedData.Factory<>(KaijuManager::new, KaijuManager::load, null), NAME);
    }

    // ---- Lock ----

    /** Beansprucht den Godzilla-Slot. Gibt false zurück, wenn bereits ein anderer Godzilla existiert. */
    public boolean tryClaimGodzilla(UUID id, long gameTime) {
        if (godzillaAlive && !id.equals(godzillaId) && !isStale(gameTime)) {
            return false;
        }
        godzillaAlive = true;
        godzillaId = id;
        lastSeenTick = gameTime;
        setDirty();
        return true;
    }

    public void heartbeat(UUID id, long gameTime) {
        if (godzillaAlive && id.equals(godzillaId)) {
            lastSeenTick = gameTime;
        }
    }

    public void releaseGodzilla(UUID id, long gameTime, long cooldownTicks) {
        if (godzillaAlive && id.equals(godzillaId)) {
            godzillaAlive = false;
            godzillaId = null;
            cooldownUntil = gameTime + cooldownTicks;
            setState(KaijuEventState.EVENT_COMPLETE);
            setDirty();
        }
    }

    public boolean isGodzillaAlive(long gameTime) {
        return godzillaAlive && !isStale(gameTime);
    }

    public boolean canStartEvent(long gameTime) {
        return !isGodzillaAlive(gameTime) && gameTime >= cooldownUntil
                && (state == KaijuEventState.NORMAL || state == KaijuEventState.EVENT_COMPLETE);
    }

    private boolean isStale(long gameTime) {
        return gameTime - lastSeenTick > STALE_TICKS;
    }

    // ---- Event-Zustand ----

    public KaijuEventState getState() {
        return state;
    }

    public void setState(KaijuEventState newState) {
        if (this.state != newState) {
            this.state = newState;
            setDirty();
        }
    }

    // ---- Persistenz ----

    private static KaijuManager load(CompoundTag tag, HolderLookup.Provider provider) {
        KaijuManager m = new KaijuManager();
        m.godzillaAlive = tag.getBoolean("GodzillaAlive");
        if (tag.hasUUID("GodzillaId")) m.godzillaId = tag.getUUID("GodzillaId");
        m.lastSeenTick = tag.getLong("LastSeen");
        m.cooldownUntil = tag.getLong("CooldownUntil");
        try {
            m.state = KaijuEventState.valueOf(tag.getString("State"));
        } catch (IllegalArgumentException e) {
            m.state = KaijuEventState.NORMAL;
        }
        return m;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider provider) {
        tag.putBoolean("GodzillaAlive", godzillaAlive);
        if (godzillaId != null) tag.putUUID("GodzillaId", godzillaId);
        tag.putLong("LastSeen", lastSeenTick);
        tag.putLong("CooldownUntil", cooldownUntil);
        tag.putString("State", state.name());
        return tag;
    }
}
