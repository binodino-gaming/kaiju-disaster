package com.kaijudisaster.event;

public enum KaijuEventState {
    NORMAL,
    WARNING,
    GODZILLA_APPROACHING,
    GODZILLA_ATTACK,
    GHIDORAH_SPAWN,
    KAIJU_BATTLE,
    CITY_DESTROYED,
    EVENT_COMPLETE
}
