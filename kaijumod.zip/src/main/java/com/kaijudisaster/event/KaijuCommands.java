package com.kaijudisaster.event;

import com.kaijudisaster.KaijuMod;
import com.mojang.brigadier.Command;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

@EventBusSubscriber(modid = KaijuMod.MOD_ID)
public class KaijuCommands {
    @SubscribeEvent
    public static void register(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("kaiju")
                .requires(s -> s.hasPermission(2))
                .then(Commands.literal("start").executes(ctx -> {
                    var player = ctx.getSource().getPlayerOrException();
                    boolean ok = KaijuEventManager.startEvent(player);
                    ctx.getSource().sendSuccess(() -> Component.translatable(ok
                            ? "message.kaiju_disaster.event_started"
                            : "message.kaiju_disaster.event_blocked"), true);
                    return ok ? Command.SINGLE_SUCCESS : 0;
                })));
    }
}
