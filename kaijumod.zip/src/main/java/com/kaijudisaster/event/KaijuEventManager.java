package com.kaijudisaster.event;

import com.kaijudisaster.KaijuMod;
import com.kaijudisaster.entity.GodzillaEntity;
import com.kaijudisaster.registry.ModEntities;
import com.kaijudisaster.registry.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.tags.FluidTags;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/**
 * Steuert den Ablauf WARNING -> GODZILLA_APPROACHING (Auftauchen) -> GODZILLA_ATTACK.
 * Die Auftauch-Animation selbst läuft in {@link GodzillaEntity}.
 */
@EventBusSubscriber(modid = KaijuMod.MOD_ID)
public class KaijuEventManager {
    private static final int WARNING_TICKS = 20 * 30;
    private static long warningStart = -1;
    private static ServerPlayer witness;

    /** Von Command/Test oder natürlichem Zufall aufgerufen. */
    public static boolean startEvent(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        KaijuManager mgr = KaijuManager.get(level.getServer());
        if (!mgr.canStartEvent(level.getGameTime())) return false;
        mgr.setState(KaijuEventState.WARNING);
        warningStart = level.getGameTime();
        witness = player;
        level.setWeatherParameters(0, 20 * 60 * 10, true, true);
        player.displayClientMessage(Component.translatable("message.kaiju_disaster.warning"), false);
        return true;
    }

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        var server = event.getServer();
        KaijuManager mgr = KaijuManager.get(server);
        if (mgr.getState() != KaijuEventState.WARNING || witness == null) return;
        ServerLevel level = witness.serverLevel();
        long elapsed = level.getGameTime() - warningStart;

        if (elapsed % 120 == 0) { // Sirene / tiefes Grollen im Abstand
            level.playSound(null, witness.blockPosition(), ModSounds.SIREN.get(), SoundSource.AMBIENT, 4.0F, 1.0F);
        }
        if (elapsed >= WARNING_TICKS) {
            if (spawnInOcean(level, witness)) {
                mgr.setState(KaijuEventState.GODZILLA_APPROACHING);
            } else {
                mgr.setState(KaijuEventState.NORMAL); // kein Meer gefunden -> abbrechen
            }
            witness = null;
            warningStart = -1;
        }
    }

    /** Sucht tiefes Wasser im Abstand 120–200 Blöcke und lässt Godzilla dort aus der Tiefe aufsteigen. */
    private static boolean spawnInOcean(ServerLevel level, ServerPlayer player) {
        RandomSource rnd = level.random;
        for (int attempt = 0; attempt < 40; attempt++) {
            double ang = rnd.nextDouble() * Math.PI * 2;
            double dist = 120 + rnd.nextDouble() * 80;
            int x = (int) (player.getX() + Math.cos(ang) * dist);
            int z = (int) (player.getZ() + Math.sin(ang) * dist);
            level.getChunk(x >> 4, z >> 4); // erzwingt Laden
            int floor = level.getHeight(Heightmap.Types.OCEAN_FLOOR, x, z);
            int surface = level.getHeight(Heightmap.Types.WORLD_SURFACE, x, z);
            BlockPos top = new BlockPos(x, surface - 1, z);
            if (!level.getFluidState(top).is(FluidTags.WATER) || surface - floor < 25) continue;

            GodzillaEntity g = ModEntities.GODZILLA.get().create(level);
            if (g == null) return false;
            // Start unter Wasser, steigt in der EMERGE-Phase auf
            g.moveTo(x + 0.5, Math.max(floor, surface - 48), z + 0.5, (float) Math.toDegrees(ang) + 90f, 0);
            g.finalizeSpawn(level, level.getCurrentDifficultyAt(g.blockPosition()), MobSpawnType.EVENT, null);
            return level.addFreshEntity(g); // Lock-Check läuft im Join-Event
        }
        return false;
    }
}
