package com.kaijudisaster.event;

import com.kaijudisaster.KaijuMod;
import com.kaijudisaster.entity.GodzillaEntity;
import com.kaijudisaster.registry.ModEntities;
import net.minecraft.network.chat.Component;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;

@EventBusSubscriber(modid = KaijuMod.MOD_ID)
public class CommonEvents {

    /** Verhindert jeden zweiten Godzilla – egal ob Event, Spawn Egg oder Command. */
    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide()) return;
        if (event.getEntity() instanceof GodzillaEntity g && !g.acquireGlobalLock()) {
            event.setCanceled(true);
            event.getLevel().players().forEach(p ->
                    p.displayClientMessage(Component.translatable("message.kaiju_disaster.godzilla_exists"), true));
        }
    }

    @EventBusSubscriber(modid = KaijuMod.MOD_ID, bus = EventBusSubscriber.Bus.MOD)
    public static class ModBus {
        @SubscribeEvent
        public static void attributes(EntityAttributeCreationEvent event) {
            event.put(ModEntities.GODZILLA.get(), GodzillaEntity.createAttributes().build());
        }
    }
}
