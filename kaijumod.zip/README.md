# Kaiju Disaster: Minus One – Phase 1

NeoForge 21.1.219 · Minecraft 1.21.1 · Java 21

## Starten
```
./gradlew build        # Windows: gradlew.bat build  -> build/libs/kaiju_disaster-0.1.0.jar
./gradlew runClient    # Testspiel starten
```
Im Spiel: `/kaiju start` (OP) startet das Event: 30 s Warnung mit Sirene und Gewitter, danach
steigt Godzilla 120–200 Blöcke entfernt aus dem Meer auf. Alternativ das Spawn Egg im Creative-Tab.

## Enthalten
- Creative-Tab (auto-befüllt aus `ModItems.TAB_ORDER`) mit Godzilla Spawn Egg
- `KaijuManager`: globaler Spawn-Lock (`GodzillaAlive`), Event-Zustände, Cooldown, Persistenz
- Lock greift für Event, Spawn Egg und Commands (`EntityJoinLevelEvent`)
- `GodzillaEntity` (18x50), Phasen EMERGE / WALK / CHARGE / FIRE, Bossbar
- Goals: `GodzillaTravelGoal`, `GodzillaBreathGoal`
- Atomic Breath (Aufladen, Strahl, Krater, Knockback, Feuer), budgetierte Zerstörung
- Detailliertes Cube-Modell (4x-Maßstab), glühende Augen und Dornen (Glow-Layer)
- Kamerawackeln nach Entfernung und Aktion

## Noch offen (nächste Phasen)
Japan-Dimension und Portal, Island Integrity, Nuclear Bomb Item, Ghidorah, Lightning Field,
Shader-Effekte (Chromatic Aberration, Flash), eigene Sounds (`sounds.json` nutzt Vanilla-Platzhalter).
